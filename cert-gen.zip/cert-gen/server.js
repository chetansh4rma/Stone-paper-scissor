require("dotenv").config()
const express=require("express")
const bodyParser=require("body-parser")
const mongoose=require("mongoose")

const session=require('express-session')
const passport=require('passport')
const passportLocalMongoose=require('passport-local-mongoose')

const PORT=process.env.PORT
const app=express()
// Body parsing middleware is included in newer versions of Express
app.use(express.json());
app.use(express.static("public"))
app.set("view engine","ejs")
app.use(bodyParser.urlencoded({extended:true}))

// for authentication
app.use(session({
    secret:process.env.SECRET,
    resave:false,
    saveUninitialized:false
}))

app.use(passport.initialize())
app.use(passport.session())

mongoose.connect(process.env.MONGO_DB).then(()=>console.log("Database is running successfully !")).catch((err)=>console.log(err))

const userSchema=new mongoose.Schema({
    username:String,
    password:String,
    name:String,
    role: {
        type: String,
        enum: ['user', 'admin'],
        default: 'user',
    }
})

const hashesSchema=new mongoose.Schema({
    name:String,
    hash:String
})

const Hash = mongoose.model('Hash', hashesSchema);
 
userSchema.plugin(passportLocalMongoose) // this will help in hashing and salting and also save data in DB

const User=new mongoose.model("User",userSchema)



passport.use(User.createStrategy());


passport.serializeUser(function(user, done) {
    done(null, user.id);
  });
  
passport.deserializeUser(function(id, done) {

    User.findById(id)
   .then(user => {
     done(null, user);
   })
   .catch(err => {
     done(err, null);
   });
  });

  
  const createAdminUser = async () => {
    try {
        const existingAdmin = await User.findOne({ role: 'admin' });
        if (!existingAdmin) {
            const adminData = {
                username: 'chetan@gmail.com',
                name: 'chetan',
                role: 'admin',
            };
            await User.register(adminData, 'chetan');  
            console.log('Admin user created successfully.');
        } else {
            console.log('Admin user already exists.');
        }
    } catch (error) {
        console.error('Error creating admin user:', error);
    }
};


createAdminUser();


app.get("/",(req,res)=>
{
    res.render("index")
})

app.get("/user/dashboard",(req,res)=>
{
     if(req.isAuthenticated())
     {
        res.render("dash") 
     }else{
        res.redirect("/login")
     }
})

app.get("/register",(req,res)=>
{
    res.render("register")
})

app.post("/register",(req,res)=>
{
    User.register({username:req.body.username,name:req.body.name}, req.body.password, function(err, user) {
        if (err) { 
            console.log(err)
            res.redirect("/register")
         }else{
            
            passport.authenticate("local")(req,res,function()
            {    
                res.redirect("/user/dashboard")
            })
         }
      
      
      });
})

const isAdmin = (req, res, next) => {
    if (req.isAuthenticated() && req.user.role === 'admin') {
        return next();
    } else {
        res.redirect('/login');  
    }
};

app.get("/admin",isAdmin,(req,res)=>
{
        res.render("admin") 
})

app.get("/admin/dashboard",isAdmin,(req,res)=>
{
        res.render("admin_dash") 
})

app.get("/admin/udemy",isAdmin,(req,res)=>
{
        res.render("udemy") 
})


app.get("/admin/issue",isAdmin,async(req,res)=>
{
    try {
        const certificates = await Hash.find({}, 'hash name');
        res.render("admin_issue", { certificates });
      } catch (error) {
        console.error('Error in fetch certificates:', error);
        res.status(500).send('Error');
      }
})


app.get("/login",(req,res)=>
{
    res.render("login")
})

app.post("/login",(req,res)=>
{
    const user=new User({
        username:req.body.username,
        password:req.body.password
    })

    req.login(user,function(err)
    {
        if(err)
        {
            console.log(err)
            res.redirect("/login")
        }else{
            passport.authenticate("local")(req,res,function()
            {
                 if (req.user.role === 'admin') {
                    res.redirect("/admin");
                } else {
                    res.redirect("/user/dashboard");
                }
            })
        }
    })
})






app.post('/your-backend-endpoint', (req, res) => {
  const receivedData = req.body;
  const newHash = new Hash({
    name: receivedData.name,
    hash: receivedData.hash
  });

  newHash.save()
  .then(result => {
    console.log('hash saved:', result);
  })
  .catch(error => {
    console.error('Error saving hash:', error);
  });


  res.json({ message: 'Data received successfully' });
});




app.listen(PORT,()=>console.log(`Server is running on port ${PORT}`))


