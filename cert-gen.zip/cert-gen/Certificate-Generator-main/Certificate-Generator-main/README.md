# Certificate-Generator

Note: This project is made for FUN purpose only. Please don't misuse it.

Recommended to use this website on your Laptop/PC for better results.

**Demo Video**: 

https://github.com/shubho0908/Certificate-Generator/assets/81776711/8474af06-8e64-477f-84ad-e48135f313ad





# Udemy Generated Certificate Sample

![sample1](https://user-images.githubusercontent.com/81776711/175827119-08871ae1-da09-41d5-9924-db974cf11adc.JPG)


# LinkedIn Learning Generated Certificate Sample

![sample2](https://user-images.githubusercontent.com/81776711/175827174-113c97f1-9895-4a37-ba7d-37aa5040f63e.JPG)
